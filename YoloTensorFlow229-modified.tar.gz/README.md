# YoloTensorFlow229
CS 229 Course Project. Lambert, Vilim, Buhler

The pre-trained weights are too big to stick on Github, so you'll need to download them from <https://drive.google.com/file/d/0BzlId5XmJ-sNWkhXSVVaVjBfSVk/view?usp=sharing>

Run `python yolo.py --image_path data/dog.jpg --checkpoint_path yolo.ckpt` for images
Run `python yolo.py --video_path data/input.mp4 --start frame1 --end frame2 --checkpoint_path yolo.ckpt` for videos

Run 'python TrainYolo.py' to train the network
