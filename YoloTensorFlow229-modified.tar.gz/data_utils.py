# John Lambert, Matt Vilim, Konstantine Buhler
# CS 229 Course Project
# "You Only Look Once" YOLO Detection