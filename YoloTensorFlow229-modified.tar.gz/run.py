# John Lambert, Matt Vilim, Konstantine Buhler
# CS 229 Course Project
# "You Only Look Once" YOLO Detection


from cnn_layer_utils import *
from data_utils import *

def YoloNetwork():

	def __init__():
		pass

	def trainNetwork():
		pass

	def testNetwork():
		pass


if __name__ == '__main__':
	runNetwork()